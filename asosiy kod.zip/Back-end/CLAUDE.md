# Hamroh — codebase rules

Post-discharge patient monitoring. Flask + Jinja2 + SQLite + a local design system
(`static/css/styles.css`) + vanilla JS polling. No CDN, no build step — the app must
render correctly with no internet connection.
Full architecture spec: PLAN.md (authoritative).

## Hard rules
- SQL lives ONLY in `repos/`. Routes do HTTP, services do logic.
- New persona / question / day = new row in a migration. Zero Python changes.
  Never branch on `persona_key`.
- New behavior goes in `analyzers/`, `hooks/`, or `notifiers/` as a NEW FILE — not as an
  `if` inside an existing service.
- Schema changes = new numbered file in `migrations/`. Never edit an applied migration.
- All `/api/v1/*` responses use `core/responses.ok()` / `fail()`. No hand-built JSON shapes.
- LLM prompts live in `prompts/*.txt`, never inline in Python.
- LLM output is untrusted: parse defensively, always fall back to `rule_analyzer`.
- Secrets in `.env` only. `.env`, `*.db`, `__pycache__/` are gitignored.

## Frontend
- Two layouts, one design system: `_layout_patient.html` (`.mode-patient`, big type,
  bottom tab bar) and `_layout_doctor.html` (`.mode-doctor`, dense, left sidebar).
  A page picks one with `{% extends %}` and sets `{% set nav = '...' %}`.
- Templates receive ids and names only; everything else is fetched from `/api/v1/*`
  with `api.get/post` (`static/js/api.js`). Never render a data table server-side
  that the API already exposes.
- Shared helpers (`icon`, `riskBadge`, `toast`, `sheet`, `lineChart`, `donut`, `esc`,
  Latin↔Cyrillic switch) live in `static/js/app.js`. Page-specific JS goes in that
  page's `{% block scripts %}`.
- Risk is never colour alone: colour + icon + word (`riskBadge()`).
- Colours, spacing and type come from CSS variables in `styles.css`. No hardcoded hex
  in templates.

## Language
User-facing text (UI, questions, messages, user-visible errors): Uzbek, Latin script.
Code, comments, commits: English.

## Commands
    python app.py            # dev server
    pytest -q                # smoke tests
    curl localhost:5000/health

## Before finishing any task
Start the app, exercise the changed path, run pytest, and paste real output. Do not claim
something works without running it.
