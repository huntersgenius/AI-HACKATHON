"""Bemor ilovasining sahifalari (yangi frontend).

Har bir sahifa faqat id/nom beradi — ma'lumot `/api/v1/*` dan `fetch` bilan
keladi (routes/pages.py dagi qoidaning davomi). Shu sababli bu yerda hech
qanday hisob-kitob yo'q: bemor qatorini topamiz va templatega uzatamiz.
"""

from flask import Blueprint, render_template

from core.auth import current_user, role_required
from repos import doctor_repo
from services import patient_profile_service

bp = Blueprint("patient_pages", __name__, url_prefix="/patient")


def _me():
    """Joriy foydalanuvchining bemor qatori (bo'lmasa — yaratiladi)."""
    patient = patient_profile_service.get_or_create_for_user(current_user())
    doctor = doctor_repo.get(patient["doctor_id"]) if patient["doctor_id"] else None
    return patient, doctor


@bp.get("")
@role_required("patient")
def home():
    patient, doctor = _me()
    return render_template("patient_home.html", patient=patient, doctor=doctor)


@bp.get("/chat")
@role_required("patient")
def chat():
    patient, doctor = _me()
    return render_template("patient_chat.html", patient=patient, doctor=doctor)


@bp.get("/trend")
@role_required("patient")
def trend():
    patient, doctor = _me()
    return render_template("patient_trend.html", patient=patient, doctor=doctor)


@bp.get("/meds")
@role_required("patient")
def meds():
    patient, doctor = _me()
    return render_template("patient_meds.html", patient=patient, doctor=doctor)


@bp.get("/alerts")
@role_required("patient")
def alerts():
    patient, doctor = _me()
    return render_template("patient_alerts.html", patient=patient, doctor=doctor)


@bp.get("/doctor")
@role_required("patient")
def my_doctor():
    """Shifokor kartochkasi yoki ulanish kodi formasi — bitta sahifa,
    ikki holat (dizayn brifi 6.2.5)."""
    patient, _doctor = _me()
    return render_template(
        "patient_doctor.html",
        patient=patient,
        detail=patient_profile_service.get_detail(patient["id"]),
    )
