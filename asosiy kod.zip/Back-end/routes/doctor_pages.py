"""Shifokor panelining bosh sahifasi (yangi frontend).

Bemorlar ro'yxati va statistikasi `/api/v1/doctors/<id>/dashboard` dan
polling bilan keladi; bu yerda faqat sahifa uchun kerak bo'lgan statik
kontekst — shifokor qatori, ulanish kodi va ochiq so'rovlar — tayyorlanadi.
"""

from flask import Blueprint, render_template

from core.auth import current_user, doctor_profile_required
from repos import doctor_repo
from services import connect_code_service, consultation_service

bp = Blueprint("doctor_pages", __name__, url_prefix="/doctor")


@bp.get("")
@doctor_profile_required
def dashboard():
    doctor = doctor_repo.get_by_user(current_user()["id"])
    connect_code, _expires = connect_code_service.get_or_create(doctor)
    open_consultations = consultation_service.list_open_for_doctor(doctor)
    return render_template(
        "doctor_dashboard.html",
        doctor=doctor,
        connect_code=connect_code,
        recent_consultations=open_consultations[:4],
        open_count=len(open_consultations),
    )
