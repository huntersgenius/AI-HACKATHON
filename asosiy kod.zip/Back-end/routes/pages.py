"""Umumiy sahifalar: landing, service worker va shifokor ko'radigan bemor kartasi.

Templatelar faqat id va nom oladi — ma'lumot API orqali keladi.
"""

import os

from flask import Blueprint, current_app, render_template, send_from_directory

from core.auth import current_user, login_required, require_patient_access
from core.errors import NotFound
from repos import doctor_repo, patient_repo
from services import doctor_service

bp = Blueprint("pages", __name__)


@bp.get("/sw.js")
def service_worker():
    """Served from the root path (not /static/) so its scope covers the
    whole app — push notification clicks need to find/focus any open tab."""
    return send_from_directory(
        os.path.join(current_app.root_path, "static"), "sw.js",
        mimetype="application/javascript",
    )


@bp.get("/")
def landing():
    """Ochiq marketing sahifasi. Kirgan foydalanuvchi uchun yuqoridagi
    tugma to'g'ridan-to'g'ri ilovaga olib boradi (landing.html ichida)."""
    return render_template("landing.html")


@bp.get("/doctor/patient/<int:pid>")
@login_required
def doctor_patient(pid):
    """Bemor kartasi — shifokor ko'rinishi.

    `require_patient_access` bitta joyda tekshiradi: shifokor faqat o'ziga
    biriktirilgan bemorni, bemor esa faqat o'zini ko'ra oladi.
    """
    patient = patient_repo.get(pid)
    if patient is None:
        raise NotFound("Bemor topilmadi.")
    require_patient_access(patient)
    doctor = doctor_repo.get(patient["doctor_id"]) if patient["doctor_id"] else None
    return render_template("doctor_patient.html", patient=patient, doctor=doctor)


# --- Eski demo manzillari -------------------------------------------------
# Bular auth tizimidan oldin yozilgan va testlar hamon ularga tayanadi
# (tests/test_auth.py::test_legacy_demo_routes_still_work_without_login).
# Yangi, sessiyaga bog'langan manzillar: /patient va /doctor.

@bp.get("/patient/<int:pid>/chat")
def demo_patient_chat(pid):
    patient = patient_repo.get(pid)
    if patient is None:
        raise NotFound("Bemor topilmadi.")
    return render_template("patient_chat.html", patient=patient, doctor=None)


@bp.get("/doctor/<int:did>/dashboard")
def demo_doctor_dashboard(did):
    doctor = doctor_service.get_doctor(did)  # raises NotFound in Uzbek
    return render_template(
        "doctor_dashboard.html",
        doctor=doctor,
        connect_code=None,
        recent_consultations=[],
        open_count=0,
    )
