/* ==========================================================================
   Hamroh⁺ — umumiy JS. Kutubxona yo'q, CDN yo'q.
   Ma'lumot bu yerda saqlanmaydi — sahifalar /api/v1/* dan `api.get/post`
   orqali oladi (api.js ga qarang).
   ========================================================================== */

/* --- Ikonlar (chiziqli, sodda) ------------------------------------------ */
const ICO = {
  home:'<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5"/>',
  check:'<polyline points="20 6 9 17 4 12"/>',
  checkCircle:'<circle cx="12" cy="12" r="9"/><polyline points="8.5 12 11 14.5 15.5 9.5"/>',
  alert:'<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><line x1="12" y1="9" x2="12" y2="13.5"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
  info:'<circle cx="12" cy="12" r="9"/><line x1="12" y1="16" x2="12" y2="11.5"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
  eye:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3"/>',
  chart:'<path d="M3 3v18h18"/><polyline points="7 14 11 10 14.5 13.5 20 8"/>',
  pill:'<rect x="2.5" y="8.5" width="19" height="7" rx="3.5" transform="rotate(-45 12 12)"/><line x1="8.2" y1="8.2" x2="15.8" y2="15.8"/>',
  file:'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><polyline points="14 3 14 8 19 8"/>',
  user:'<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  stetho:'<path d="M4.8 2.3A.3.3 0 1 0 5 2H4a2 2 0 0 0-2 2v5a6 6 0 0 0 6 6 6 6 0 0 0 6-6V4a2 2 0 0 0-2-2h-1a.2.2 0 1 0 .3.3"/><path d="M8 15v1a6 6 0 0 0 12 0v-4"/><circle cx="20" cy="10" r="2"/>',
  bell:'<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
  msg:'<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  send:'<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
  plus:'<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  arrowR:'<line x1="4" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/>',
  arrowL:'<line x1="20" y1="12" x2="5" y2="12"/><polyline points="11 18 5 12 11 6"/>',
  chevR:'<polyline points="9 5 16 12 9 19"/>',
  clock:'<circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15.5 14"/>',
  cal:'<rect x="3" y="5" width="18" height="16" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="8" y1="3" x2="8" y2="7"/><line x1="16" y1="3" x2="16" y2="7"/>',
  shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  shieldOk:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 9.5"/>',
  lock:'<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
  heart:'<path d="M20.8 5.6a5 5 0 0 0-7.1 0L12 7.3l-1.7-1.7a5 5 0 0 0-7.1 7.1l8.8 8.8 8.8-8.8a5 5 0 0 0 0-7.1z"/>',
  pulse:'<polyline points="2 12 6 12 9 4 15 20 18 12 22 12"/>',
  drop:'<path d="M12 2.5S6 9 6 13.5a6 6 0 0 0 12 0C18 9 12 2.5 12 2.5z"/>',
  gear:'<circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1A1.6 1.6 0 0 0 9 19.4a1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1A1.6 1.6 0 0 0 4.6 9a1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z"/>',
  logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
  search:'<circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.7" y2="16.7"/>',
  filter:'<polygon points="22 3 2 3 10 12.5 10 19 14 21 14 12.5 22 3"/>',
  key:'<circle cx="7.5" cy="15.5" r="4.5"/><line x1="10.7" y1="12.3" x2="21" y2="2"/><line x1="17" y1="6" x2="20" y2="9"/>',
  copy:'<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  refresh:'<polyline points="22 12 22 6 16 6"/><path d="M22 6 15 13a5 5 0 0 1-7 0l-1-1"/><polyline points="2 12 2 18 8 18"/><path d="M2 18l7-7a5 5 0 0 1 7 0l1 1"/>',
  flame:'<path d="M12 22c4 0 7-2.8 7-6.5 0-4.5-4.5-6.2-4-11.5-2.5 1.5-4 4-4 6 0 1.5-1 2-1.6 1.2C8.5 9.7 8 8.5 8 7.5 6 9.5 5 12 5 15.5 5 19.2 8 22 12 22z"/>',
  spark:'<path d="M12 2.5 13.9 9 20.5 11l-6.6 2L12 19.5 10.1 13 3.5 11 10.1 9z"/>',
  edit:'<path d="M11 4H5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h13a2 2 0 0 0 2-2v-6"/><path d="M18.5 2.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4z"/>',
  download:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
  play:'<circle cx="12" cy="12" r="9"/><polygon points="10 8.5 16 12 10 15.5"/>',
  wifiOff:'<line x1="2" y1="2" x2="22" y2="22"/><path d="M8.5 16.4a5 5 0 0 1 7 0"/><path d="M5 12.9a10 10 0 0 1 5.2-2.6"/><path d="M19 12.9a10 10 0 0 0-3.5-2.3"/><line x1="12" y1="20" x2="12.01" y2="20"/>',
};

function icon(name, size, cls){
  const p = ICO[name] || '';
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" '
       + 'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"'
       + (size ? ' width="'+size+'" height="'+size+'"' : '')
       + (cls ? ' class="'+cls+'"' : '') + '>' + p + '</svg>';
}

/* Sahifadagi <i data-ico="name"> larni to'ldirish */
function mountIcons(root){
  (root || document).querySelectorAll('[data-ico]').forEach(el=>{
    if(el.dataset.mounted) return;
    el.innerHTML = icon(el.dataset.ico, el.dataset.size);
    el.style.display = 'inline-flex';
    el.dataset.mounted = '1';
  });
}

/* --- Xavf belgisi: rang + ikon + so'z ----------------------------------- */
const RISK_META = {
  green:  { cls:'risk-ok',   ico:'checkCircle', word:'Barqaror' },
  yellow: { cls:'risk-warn', ico:'eye',         word:'Kuzatuvda' },
  red:    { cls:'risk-red',  ico:'alert',       word:'E’tibor kerak' },
  none:   { cls:'risk-none', ico:'clock',       word:'Ma’lumot yo’q' },
};
function riskBadge(level, word){
  const m = RISK_META[level] || RISK_META.none;
  return '<span class="risk '+m.cls+'">'+icon(m.ico)+'<span>'+(word||m.word)+'</span></span>';
}

/* --- Toast --------------------------------------------------------------- */
function toast(text, kind){
  let box = document.querySelector('.toasts');
  if(!box){ box = document.createElement('div'); box.className='toasts'; document.body.appendChild(box); }
  const t = document.createElement('div');
  t.className = 'toast' + (kind ? ' is-'+kind : '');
  t.innerHTML = icon(kind==='risk'?'alert':'check') + '<span>'+text+'</span>';
  box.appendChild(t);
  setTimeout(()=>{ t.style.transition='opacity .25s'; t.style.opacity='0';
                   setTimeout(()=>t.remove(), 260); }, 2800);
}

/* --- Modal --------------------------------------------------------------- */
function sheet(html){
  const bg = document.createElement('div');
  bg.className = 'sheet-bg';
  bg.innerHTML = '<div class="sheet"><div class="sheet-grip"></div>'+html+'</div>';
  bg.addEventListener('click', e=>{ if(e.target===bg) bg.remove(); });
  document.body.appendChild(bg);
  mountIcons(bg);
  return bg;
}

/* --- Chiziqli grafik (sof SVG) ------------------------------------------- */
/* series: [{data:[...], color:'#..', width:2.5, dots:true}]
   opts: {labels:[], min, max, bands:[{v, color, label}], h} */
function lineChart(el, series, opts){
  opts = opts || {};
  const W = 640, H = opts.h || 210;
  const pad = { l:34, r:12, t:14, b:26 };
  const all = series.flatMap(s=>s.data);
  if(!all.length){ el.innerHTML = '<p class="sm dim center" style="padding:28px 0">Hali ma\'lumot yo\'q</p>'; return; }
  const min = opts.min != null ? opts.min : Math.floor(Math.min(...all) - 1);
  const max = opts.max != null ? opts.max : Math.ceil(Math.max(...all) + 1);
  const n = series[0].data.length;
  const px = i => pad.l + (n<2?0:i*((W-pad.l-pad.r)/(n-1)));
  const py = v => pad.t + (max-v)/((max-min)||1)*(H-pad.t-pad.b);
  let g = '';

  const ticks = opts.ticks || 4;
  for(let k=0;k<=ticks;k++){
    const v = min + (max-min)*k/ticks;
    g += '<line x1="'+pad.l+'" y1="'+py(v).toFixed(1)+'" x2="'+(W-pad.r)+'" y2="'+py(v).toFixed(1)
       + '" stroke="#E3EBE8" stroke-width="1"/>'
       + '<text x="'+(pad.l-7)+'" y="'+(py(v)+4).toFixed(1)+'" font-size="11" fill="#8B9A95" text-anchor="end">'
       + (Math.round(v*10)/10) + '</text>';
  }
  (opts.bands||[]).forEach(b=>{
    g += '<line x1="'+pad.l+'" y1="'+py(b.v).toFixed(1)+'" x2="'+(W-pad.r)+'" y2="'+py(b.v).toFixed(1)
       + '" stroke="'+b.color+'" stroke-width="1.4" stroke-dasharray="5 4" opacity=".75"/>';
  });
  series.forEach(s=>{
    const d = s.data.map((v,i)=>(i?'L':'M')+px(i).toFixed(1)+','+py(v).toFixed(1)).join(' ');
    if(s.fill){
      g += '<path d="'+d+' L'+px(n-1).toFixed(1)+','+(H-pad.b)+' L'+px(0).toFixed(1)+','+(H-pad.b)+' Z" '
         + 'fill="'+s.color+'" opacity=".07"/>';
    }
    g += '<path d="'+d+'" fill="none" stroke="'+s.color+'" stroke-width="'+(s.width||2.5)
       + '" stroke-linejoin="round" stroke-linecap="round"/>';
    if(s.dots !== false){
      s.data.forEach((v,i)=>{
        let c = s.color;
        if(opts.markOut){ if(v > opts.markOut.hi) c = '#DC2626'; else if(v < opts.markOut.lo) c = '#B45309'; }
        const r = (c === s.color) ? 3 : 4.5;
        g += '<circle cx="'+px(i).toFixed(1)+'" cy="'+py(v).toFixed(1)+'" r="'+r+'" fill="'+c+'"/>';
      });
    }
  });
  (opts.labels||[]).forEach((t,i)=>{
    g += '<text x="'+px(i).toFixed(1)+'" y="'+(H-7)+'" font-size="11" fill="#8B9A95" text-anchor="middle">'+t+'</text>';
  });
  el.innerHTML = '<svg viewBox="0 0 '+W+' '+H+'" role="img">'+g+'</svg>';
}

/* --- Halqa (donut) ------------------------------------------------------- */
function donut(el, parts, centerN, centerL){
  const R = 54, C = 2*Math.PI*R;
  const total = parts.reduce((a,p)=>a+p.v,0) || 1;
  let off = 0, g = '<circle cx="66" cy="66" r="'+R+'" fill="none" stroke="#EDF3F1" stroke-width="15"/>';
  parts.forEach(p=>{
    const len = C*p.v/total;
    g += '<circle cx="66" cy="66" r="'+R+'" fill="none" stroke="'+p.color+'" stroke-width="15" '
       + 'stroke-dasharray="'+len.toFixed(2)+' '+(C-len).toFixed(2)+'" stroke-dashoffset="'+(-off).toFixed(2)+'"/>';
    off += len;
  });
  el.innerHTML = '<svg viewBox="0 0 132 132">'+g+'</svg>'
    + '<div class="ring-mid"><div class="ring-n">'+centerN+'</div><div class="ring-l">'+centerL+'</div></div>';
}

/* --- Raqam sanash -------------------------------------------------------- */
function countUp(el, to, ms){
  const dur = ms || 700, t0 = performance.now();
  const dec = (String(to).indexOf('.') > -1) ? 1 : 0;
  (function tick(t){
    const k = Math.min(1, (t-t0)/dur);
    const e = 1 - Math.pow(1-k, 3);
    el.textContent = (to*e).toFixed(dec);
    if(k < 1) requestAnimationFrame(tick); else el.textContent = to;
  })(t0);
}

/* --- Yordamchi ----------------------------------------------------------- */
const $  = (s,r)=> (r||document).querySelector(s);
const $$ = (s,r)=> Array.from((r||document).querySelectorAll(s));
const initials = n => (n||'').split(' ').filter(Boolean).slice(0,2).map(w=>w[0]).join('').toUpperCase();
/* HTML ga qo'yishdan oldin — server matni foydalanuvchidan kelgan bo'lishi mumkin */
const esc = s => String(s == null ? '' : s)
  .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
  .replace(/"/g,'&quot;').replace(/'/g,'&#39;');

/* Sahifa <body data-...> dan kontekst oladi — id lar Jinja'dan keladi */
const CTX = (() => {
  const d = document.body ? document.body.dataset : {};
  return {
    patientId: d.patientId ? +d.patientId : null,
    doctorId:  d.doctorId  ? +d.doctorId  : null,
    role:      d.role || null,
  };
})();

/* API xatosini bir joyda ko'rsatamiz */
function apiFail(err){
  toast((err && err.message) || 'Xatolik yuz berdi', 'risk');
  if (window.console) console.error(err);
}

/* ==========================================================================
   Til: lotin ↔ kirill
   Matn bir marta lotinda yoziladi, kirill avtomatik hosil qilinadi.
   Shifokorlar odatda kirillda o'qiydi va yozadi.
   ========================================================================== */

/* Tarjima qilinmaydigan so'zlar — brend, birlik, qisqartma */
const TR_KEEP = /(Hamroh|HbA1c|mmol\/l|mmol|mmHg|bpm|SpO₂|SpO2|PDF|SMS|DMED|Google|Telegram|PWA|HMR-\d+|HM-\d+|ISO|AI)/g;
/* Qo'lda belgilangan mosliklar (avtomatik qoida noto'g'ri beradigan holatlar) */
const TR_DIRECT = { 'OSHP':'ОШП' };

function translit(s){
  if(!s) return s;

  /* 1. Himoyalangan so'zlarni vaqtincha olib turamiz */
  const kept = [];
  s = s.replace(TR_KEEP, m => { kept.push(m); return '' + (kept.length - 1) + ''; });
  for(const k in TR_DIRECT) s = s.split(k).join(TR_DIRECT[k]);

  /* 2. Apostroflarni bir shaklga keltiramiz */
  s = s.replace(/[ʻʼ‘’`´]/g, "'");

  /* 3. Qo'shharflar — birinchi navbatda */
  const DI = [
    ["O'",'Ў'],["o'",'ў'],["G'",'Ғ'],["g'",'ғ'],
    ['SH','Ш'],['Sh','Ш'],['sh','ш'],
    ['CH','Ч'],['Ch','Ч'],['ch','ч'],
    ['TS','Ц'],['Ts','Ц'],['ts','ц'],
    ['YA','Я'],['Ya','Я'],['ya','я'],
    ['YO','Ё'],['Yo','Ё'],['yo','ё'],
    ['YU','Ю'],['Yu','Ю'],['yu','ю'],
    ['YE','Е'],['Ye','Е'],['ye','е'],
  ];
  for(const [a,b] of DI) s = s.split(a).join(b);

  /* 4. So'z boshidagi e → э */
  s = s.replace(/(^|[^A-Za-zЀ-ӿ])e/g, (m,p)=> p + 'э');
  s = s.replace(/(^|[^A-Za-zЀ-ӿ])E/g, (m,p)=> p + 'Э');

  /* 5. Yakka harflar */
  const M = {
    a:'а',b:'б',c:'к',d:'д',e:'е',f:'ф',g:'г',h:'ҳ',i:'и',j:'ж',k:'к',l:'л',
    m:'м',n:'н',o:'о',p:'п',q:'қ',r:'р',s:'с',t:'т',u:'у',v:'в',w:'в',x:'х',
    y:'й',z:'з',
    A:'А',B:'Б',C:'К',D:'Д',E:'Е',F:'Ф',G:'Г',H:'Ҳ',I:'И',J:'Ж',K:'К',L:'Л',
    M:'М',N:'Н',O:'О',P:'П',Q:'Қ',R:'Р',S:'С',T:'Т',U:'У',V:'В',W:'В',X:'Х',
    Y:'Й',Z:'З',
    "'":'ъ'
  };
  s = s.replace(/[A-Za-z']/g, ch => M[ch] || ch);

  /* 6. Himoyalanganlarni qaytaramiz */
  return s.replace(/(\d+)/g, (m,i)=> kept[+i]);
}

/* Teskari: kirill → lotin.
   Foydalanuvchi kirillda yozsa ham qidiruv va AI tahlili ishlashi uchun. */
const CYR2LAT = {
  'а':'a','б':'b','в':'v','г':'g','ғ':'g\'','д':'d','е':'e','ё':'yo','ж':'j',
  'з':'z','и':'i','й':'y','к':'k','қ':'q','л':'l','м':'m','н':'n','о':'o',
  'ў':'o\'','п':'p','р':'r','с':'s','т':'t','у':'u','ф':'f','х':'x','ҳ':'h',
  'ц':'ts','ч':'ch','ш':'sh','щ':'sh','ъ':'\'','ы':'i','ь':'','э':'e',
  'ю':'yu','я':'ya','ң':'ng'
};
function deTranslit(s){
  if(!s) return s;
  return s.replace(/[Ѐ-ӿ]/g, ch=>{
    const low = ch.toLowerCase();
    const lat = CYR2LAT[low];
    if(lat === undefined) return ch;
    return (ch === low) ? lat : (lat.charAt(0).toUpperCase() + lat.slice(1));
  });
}

const LANG = {
  cur: 'lat',
  busy: false,

  /* Matn tugunlarini yig'ish */
  nodes(root){
    const out = [];
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(n){
        const p = n.parentElement;
        if(!p) return NodeFilter.FILTER_REJECT;
        if(p.closest('script,style,code,pre,.lang-switch,[data-no-tr]')) return NodeFilter.FILTER_REJECT;
        if(!n.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    let n; while((n = w.nextNode())) out.push(n);
    return out;
  },

  /* Bitta bo'lakni kirillga o'girish */
  toCyr(root){
    this.busy = true;
    this.nodes(root).forEach(n=>{
      if(n.__lat === undefined) n.__lat = n.nodeValue;
      n.nodeValue = translit(n.__lat);
    });
    root.querySelectorAll('[placeholder]').forEach(el=>{
      if(el.__ph === undefined) el.__ph = el.getAttribute('placeholder');
      el.setAttribute('placeholder', translit(el.__ph));
    });
    this.busy = false;
  },

  toLat(root){
    this.busy = true;
    this.nodes(root).forEach(n=>{ if(n.__lat !== undefined) n.nodeValue = n.__lat; });
    root.querySelectorAll('[placeholder]').forEach(el=>{
      if(el.__ph !== undefined) el.setAttribute('placeholder', el.__ph);
    });
    this.busy = false;
  },

  set(lang){
    this.cur = lang;
    if(lang === 'cyr') this.toCyr(document.body); else this.toLat(document.body);
    document.documentElement.setAttribute('lang', lang === 'cyr' ? 'uz-Cyrl' : 'uz');
    try{ localStorage.setItem('hamroh_lang', lang); }catch(e){}
    document.querySelectorAll('.lang-switch button').forEach(b=>
      b.classList.toggle('on', b.dataset.lang === lang));
  },

  /* Yangi qo'shilgan elementlarni ham o'girish */
  watch(){
    const obs = new MutationObserver(muts=>{
      if(this.cur !== 'cyr' || this.busy) return;
      muts.forEach(m=> m.addedNodes.forEach(n=>{
        if(n.nodeType === 1){ if(!n.closest('.lang-switch')) this.toCyr(n); }
        else if(n.nodeType === 3 && n.nodeValue.trim()){
          const p = n.parentElement;
          if(p && !p.closest('script,style,code,.lang-switch,[data-no-tr]')){
            this.busy = true;
            if(n.__lat === undefined) n.__lat = n.nodeValue;
            n.nodeValue = translit(n.__lat);
            this.busy = false;
          }
        }
      }));
    });
    obs.observe(document.body, { childList:true, subtree:true });
  },

  /* Almashtirgich tugmasini joylash */
  mount(){
    const box = document.createElement('div');
    box.className = 'lang-switch';
    box.setAttribute('data-no-tr','');
    box.innerHTML = '<button data-lang="lat" class="on">UZ</button>'
                  + '<button data-lang="cyr">ЎЗ</button>';
    box.addEventListener('click', e=>{
      const b = e.target.closest('button'); if(!b) return;
      this.set(b.dataset.lang);
    });

    const top  = document.querySelector('.topbar-in');
    const app  = document.querySelector('.appbar-in');
    const side = document.querySelector('.side .sidenav');

    if(top)       top.insertBefore(box, top.lastElementChild);
    else if(app)  app.appendChild(box);
    else if(side) side.parentElement.insertBefore(box, side);
    else { box.classList.add('lang-float'); document.body.appendChild(box); }
  },

  init(){
    this.mount();
    this.watch();
    let saved = 'lat';
    try{ saved = localStorage.getItem('hamroh_lang') || 'lat'; }catch(e){}
    if(saved === 'cyr') this.set('cyr');
  }
};

/* --- Offline holat ko'rsatkichi (PWA talabi) ----------------------------- */
function offlineBar(){
  let bar = document.getElementById('offbar');
  if(!bar){
    bar = document.createElement('div');
    bar.id = 'offbar';
    bar.style.cssText = 'position:fixed;left:0;right:0;top:0;z-index:90;display:none;'
      + 'padding:9px 16px;background:#B45309;color:#fff;font-size:13px;font-weight:600;'
      + 'text-align:center;letter-spacing:-.01em';
    bar.innerHTML = 'Internet yo\'q — ma\'lumotlar saqlanadi va ulanish tiklanganda yuboriladi';
    document.body.prepend(bar);
  }
  const sync = ()=>{ bar.style.display = navigator.onLine ? 'none' : 'block'; };
  window.addEventListener('online',  ()=>{ sync(); toast('Ulanish tiklandi','ok'); });
  window.addEventListener('offline', sync);
  sync();
}

document.addEventListener('DOMContentLoaded', ()=>{
  mountIcons();
  $$('[data-count]').forEach(el=> countUp(el, parseFloat(el.dataset.count)));
  offlineBar();
  LANG.init();
});
